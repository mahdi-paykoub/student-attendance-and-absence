

<?php $__env->startSection('content'); ?>
<div class=" mt-4">
    <h4 class="mb-4 fw-bold fs18">دانش‌آموزانی که محصول <span class="text-success"><?php echo e($product->title); ?></span>  را دارند:</h4>

    <?php if($students->isEmpty()): ?>
    <div class="alert alert-warning">هیچ دانش‌آموزی برای این محصول ثبت نشده است.</div>
    <?php else: ?>
    <div class="table-wrap">
        <div class="">
            <div class="">
                <table class="table table-striped">
                    <thead class="table-light">
                        <tr>
                            <th>نام</th>
                            <th>نام خانوادگی</th>
                            <th>کد ملی</th>
                            <th>شماره تماس</th>
                            <th>نوع پرداخت</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($student->first_name); ?></td>
                            <td><?php echo e($student->last_name); ?></td>
                            <td><?php echo e($student->national_code); ?></td>
                            <td><?php echo e($student->phone); ?></td>
                            <td>
                                <?php switch($student->pivot->payment_type):
                                case ('cash'): ?> نقدی <?php break; ?>
                                <?php case ('installment'): ?> اقساطی <?php break; ?>
                                <?php case ('scholarship'): ?> بورسیه <?php break; ?>
                                <?php default: ?> -
                                <?php endswitch; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/products/students.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'ثبت نام دانش‌آموز جدید'); ?>

<?php $__env->startSection('content'); ?>
<div class=" mt-4">
    <div class="card shadow-sm">
        <div class="card-header bg-admin-green text-white">
            <h5 class="mb-0">فرم ثبت‌نام دانش‌آموز با exel</h5>
        </div>
        <div class="card-body">

            <form action="<?php echo e(route('students.import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="d-flex align-items-center justify-content-between">
                    <input class="form-control w-75" type="file" name="file" accept=".xlsx,.xls" required>
                    <button class="btn btn-success bg-admin-green me-3" type="submit">آپلود اکسل</button>
                </div>
            </form>



            <form action="<?php echo e(route('students.photos.upload')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label class="mt-4"> ZIP تصاویر :</label>

                <div class="d-flex align-items-center justify-content-between mt-1">
                    <input type="file" class="form-control w-75" name="photos_zip" accept=".zip" required>
                    <button type="submit" class="btn btn-primary mt-2 btn btn-success bg-admin-green">آپلود تصاویر</button>
                </div>
            </form>

            <?php if(session('success')): ?>
            <div class="alert alert-success mt-3"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-danger mt-3"><?php echo e(session('error')); ?></div>
            <?php endif; ?>


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/students/import-exel.blade.php ENDPATH**/ ?>
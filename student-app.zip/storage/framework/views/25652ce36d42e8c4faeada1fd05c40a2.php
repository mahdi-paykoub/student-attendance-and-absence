

<?php $__env->startSection('title', 'افزودن کارت جدید'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header bg-admin-green text-white">افزودن کارت جدید</div>
    <div class="card-body">

        <div class="table-wrap">
            <form action="<?php echo e(route('payment-cards.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label">نام کارت</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button class="btn btn-success bg-admin-green">ذخیره</button>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/partials/payment_cards/create.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', ' مدیریت کارت ها'); ?>

<?php $__env->startSection('content'); ?>
<div class="">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fs18 fw-bold">مدیریت کارت های پرداختی</h4>
        <a href="<?php echo e(route('payment-cards.create')); ?>" class="btn btn-success bg-admin-green">افزودن کارت (پوز) جدید</a>
    </div>

    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="table-wrap">
        <table class="table table-striped">
            <thead class="table-light">
                <tr>
                    <th>نام کارت</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($card->name); ?></td>
                    <td>
                        <form action="<?php echo e(route('payment-cards.destroy', $card)); ?>" method="POST" onsubmit="return confirm('حذف کارت؟')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-secondary btn-sm">حذف</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="2" class="text-center text-muted">هیچ کارتی ثبت نشده است</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/partials/payment_cards/index.blade.php ENDPATH**/ ?>
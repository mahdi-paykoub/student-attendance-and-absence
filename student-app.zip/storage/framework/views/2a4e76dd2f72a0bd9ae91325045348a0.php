

<?php $__env->startSection('title', 'مدیریت شهرستان‌ها'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold fs18
    ">مدیریت شهرستان‌ها</h4>
    <a href="<?php echo e(route('cities.create')); ?>" class="btn btn-success bg-admin-green">افزودن شهرستان جدید</a>
</div>

<?php if(session('success')): ?>
<div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="table-wrap">
    <table class="table">
        <thead class="table-light">
            <tr>
                <th>ردیف</th>
                <th>نام شهرستان</th>
                <th>استان مربوطه</th>
                <th>عملیات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($city->name); ?></td>
                <td><?php echo e($city->province->name ?? '-'); ?></td>
                <td>
                    <a href="<?php echo e(route('cities.edit', $city)); ?>" class="btn btn-sm btn-success bg-admin-green">ویرایش</a>
                    <form action="<?php echo e(route('cities.destroy', $city)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-secondary" onclick="return confirm('حذف شود؟')">حذف</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/partials/cities/index.blade.php ENDPATH**/ ?>
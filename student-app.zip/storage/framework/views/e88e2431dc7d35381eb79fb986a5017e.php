

<?php $__env->startSection('title', "حضور و غیاب - {$exam->name}"); ?>

<?php $__env->startSection('content'); ?>
<div class=" mt-4">
    <h3 class="fw-bold fs18">دانش‌آموزان حاضر در آزمون: <span class="text-success"><?php echo e($exam->name); ?></span></h3>

    <div class="table-wrap mt-4">
        <table class="table table-striped">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>نام</th>
                    <th>نام خانوادگی</th>
                    <th>کد ملی</th>
                    <th>پایه</th>
                    <th>رشته</th>
                    <th>وضعیت حضور</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($attendance->student->first_name); ?></td>
                    <td><?php echo e($attendance->student->last_name); ?></td>
                    <td><?php echo e($attendance->student->national_code); ?></td>
                    <td><?php echo e($attendance->student->grade->name ?? '-'); ?></td>
                    <td><?php echo e($attendance->student->major->name ?? '-'); ?></td>
                    <td>
                        <?php if($attendance->is_present): ?>
                        <span class="badge bg-admin-green">حاضر</span>
                        <?php else: ?>
                        <span class="badge bg-danger">غایب</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted">هیچ دانش‌آموزی ثبت نشده است.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/exams/attendance.blade.php ENDPATH**/ ?>
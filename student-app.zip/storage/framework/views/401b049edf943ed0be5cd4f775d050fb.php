

<?php $__env->startSection('content'); ?>
<div class="">
    <h3 class="mb-4 fw-bold fs18">تنظیمات محصول الزامی برای آزمون حضوری</h3>

    <div class="table-wrap">
        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('settings.updateExamProduct')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check mt-3">
                    <input class="form-check-input" type="radio" name="product_id" id="product<?php echo e($product->id); ?>" value="<?php echo e($product->id); ?>"
                        <?php echo e($mandatoryProductId == $product->id ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="product<?php echo e($product->id); ?>">
                        <?php echo e($product->title); ?> - <?php echo e(number_format($product->price)); ?> تومان
                    </label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="text-start">
                <button type="submit" class="btn btn-success bg-admin-green">ذخیره تنظیمات</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/settings/settings_exam_product.blade.php ENDPATH**/ ?>
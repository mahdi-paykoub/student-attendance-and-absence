

<?php $__env->startSection('title', 'لیست دانش‌آموزان'); ?>

<?php $__env->startSection('content'); ?>
<div class=" mt-4">

    
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0 fw-bold fs18">لیست دانش‌آموزان</h4>
        <a href="<?php echo e(route('students.create')); ?>" class="btn btn-success bg-admin-green">
            + افزودن دانش‌آموز جدید
        </a>
    </div>

    
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    
    <div class="table-wrap">
        <div class="text-start mb-4">
            
            <form method="GET" action="<?php echo e(route('students.index')); ?>" class="mb-3 d-flex align-items-center">
                <label for="filter" class="me-2 fw-bold">فیلتر:</label>
                <select name="filter" id="filter" class="form-select w-auto me-2" onchange="this.form.submit()">
                    <option value="">همه دانش‌آموزان</option>
                    <option value="with" <?php echo e($filter === 'with' ? 'selected' : ''); ?>>دارای محصول</option>
                    <option value="without" <?php echo e($filter === 'without' ? 'selected' : ''); ?>>بدون محصول</option>
                </select>
            </form>
        </div>
        <table class="table table-striped align-middle">
            <thead class="table-light">
                <tr>
                    <th>عکس</th>
                    <th>نام</th>
                    <th>نام خانوادگی</th>
                    <th>شماره صندلی</th>
                    <th>تاریخ عضویت</th>
                    <th>محصول؟</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <!-- <td><?php echo e($loop->iteration); ?></td> -->

                    
                    <td>
                        <?php if($student->photo): ?>
                        <img src="<?php echo e(route('students.photo', basename($student->photo))); ?>"
                            alt="photo" width="50" height="50" class="rounded-circle">
                        <?php else: ?>
                        <img src="<?php echo e(asset('images/no-photo.png')); ?>" width="50" height="50" class="rounded-circle">
                        <?php endif; ?>
                    </td>

                    <td><?php echo e($student->first_name); ?></td>
                    <td><?php echo e($student->last_name); ?></td>
                    <td>
                        <?php if($student->seat_number): ?>
                        <?php echo e($student->seat_number); ?>

                        <?php endif; ?>
                    </td>
                    <td class="fs14 text-end" dir="ltr"><?php echo e(\Morilog\Jalali\Jalalian::fromDateTime($student->created_at)->format('Y/m/d H:i')); ?></td>
                    <td>
                        <?php if($student->products->count() > 0): ?>
                        <span class="badge bg-admin-green">دارد</span>
                        <?php else: ?>
                        <span class="badge bg-danger">ندارد</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <a href="<?php echo e(route('students.edit', $student)); ?>" class="btn btn-sm btn-success bg-admin-green">ویرایش</a>

                        <a href="<?php echo e(route('student-products.assign', $student->id)); ?>" class="btn btn-success bg-admin-green btn-sm">تخصیص</a>
                        <a href="<?php echo e(route('students.details', $student->id)); ?>" class="btn btn-success bg-admin-green btn-sm">
                            مشاهده مالی
                        </a>

                        <form action="<?php echo e(route('students.destroy', $student)); ?>" method="POST" class="d-inline"
                            onsubmit="return confirm('آیا از حذف این دانش‌آموز مطمئن هستید؟')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-secondary">حذف</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="11" class="text-center text-muted">هیچ دانش‌آموزی ثبت نشده است.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
  

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/students/index.blade.php ENDPATH**/ ?>
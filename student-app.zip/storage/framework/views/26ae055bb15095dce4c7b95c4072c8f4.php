

<?php $__env->startSection('content'); ?>
<h3 class="mb-4 fw-blod fs18">جزئیات دانش‌آموز: <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?></h3>

<div class="table-wrap">
    
    <div class="card mb-4">
        <div class="card-header bg-admin-green text-white">📊 خلاصه مالی دانش‌آموز</div>
        <div class="card-body">
            <div class="row text-center">
                <div class="col-md-3">
                    <strong>💰 جمع کل محصولات:</strong>
                    <p><?php echo e(number_format($totalProducts)); ?> تومان</p>
                </div>
                <div class="col-md-3">
                    <strong>💵 پرداخت نقدی:</strong>
                    <p><?php echo e(number_format($totalPayments)); ?> تومان</p>
                </div>
                <div class="col-md-3">
                    <strong>🧾 پرداخت با چک:</strong>
                    <p><?php echo e(number_format($totalChecks)); ?> تومان</p>
                </div>
                <div class="col-md-3">
                    <strong>📈 مجموع پرداختی:</strong>
                    <p><?php echo e(number_format($totalPaid)); ?> تومان</p>
                </div>
            </div>

            <hr>

            <?php if($debt > 0): ?>
            <p class="text-danger fw-bold"><strong>🔻 بدهکار:</strong> <?php echo e(number_format($debt)); ?> تومان</p>
            <?php elseif($credit > 0): ?>
            <p class="text-success fw-bold"><strong>✅ بستانکار:</strong> <?php echo e(number_format($credit)); ?> تومان</p>
            <?php else: ?>
            <p class="text-secondary fw-bold">تسویه‌شده ✅</p>
            <?php endif; ?>
        </div>
    </div>

    
    <h5 class="mb-3 fw-bold fs18">محصولات تخصیص داده‌شده</h5>

    <?php $__currentLoopData = $student->productStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <?php if($ps->payments->count() || $ps->checks->count()): ?>
    <div class="card mb-4">
        <div class="card-header bg-light">
            <strong>
                <?php echo e($ps->product->name); ?>

            </strong>
            <span class="badge bg-secondary">
                <?php if($ps->payment_type == 'cash'): ?>
                نقدی
                <?php elseif($ps->payment_type == 'installment'): ?>
                اقساطی
                <?php endif; ?>
            </span>
        </div>
        <div class="card-body">



            
            <?php if($ps->payments->count()): ?>
            <h6 class="text-success">پرداخت‌ها</h6>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>تاریخ</th>
                        <th>ساعت</th>
                        <th>مبلغ</th>
                        <th>شماره فیش</th>
                        <th>کارت</th>
                        <th>رسید</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ps->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(\Morilog\Jalali\Jalalian::fromDateTime($pay->date)->format('Y/m/d')); ?></td>
                        <td><?php echo e($pay->time); ?></td>
                        <td><?php echo e(number_format($pay->amount)); ?> تومان</td>
                        <td><?php echo e($pay->voucher_number ?? '-'); ?></td>
                        <td><?php echo e($pay->paymentCard->name ?? '-'); ?></td>
                        <td>
                            <?php if($pay->receipt_image): ?>
                            <a href="<?php echo e(route('payments.receipt', $pay->id)); ?>" target="_blank" class="btn btn-success bg-admin-green btn-sm">مشاهده</a>
                            <?php else: ?>
                            -
                            <?php endif; ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>

            
            <?php if($ps->checks->count()): ?>
            <h6 class="text-success mt-4">چک‌ها</h6>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>تاریخ</th>
                        <th>مبلغ</th>
                        <th>سریال</th>
                        <th>کد صیاد</th>
                        <th>صاحب چک</th>
                        <th>کد ملی</th>
                        <th>تلفن</th>
                        <th>عکس</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $ps->checks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(\Morilog\Jalali\Jalalian::fromDateTime($check->date)->format('Y/m/d')); ?></td>
                        <td><?php echo e(number_format($check->amount)); ?> تومان</td>
                        <td><?php echo e($check->serial); ?></td>
                        <td><?php echo e($check->sayad_code); ?></td>
                        <td><?php echo e($check->owner_name); ?></td>
                        <td><?php echo e($check->owner_national_code); ?></td>
                        <td><?php echo e($check->owner_phone); ?></td>
                        <td>
                        <td>
                            <?php if($check->check_image): ?>
                            <a href="<?php echo e(route('checks.image', $check->id)); ?>" target="_blank" class="btn btn-success bg-admin-green btn-sm">مشاهده</a>
                            <?php else: ?>
                            -
                            <?php endif; ?>
                        </td>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php endif; ?>



        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <div class="text-start">
        <a href="<?php echo e(route('students.index')); ?>" class="btn btn-secondary">بازگشت</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/students/details.blade.php ENDPATH**/ ?>
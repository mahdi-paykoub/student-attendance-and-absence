

<?php $__env->startSection('title', 'محصولات'); ?>

<?php $__env->startSection('content'); ?>
<div class=" mt-4">
    <div class="d-flex justify-content-between mb-3">
        <h4 class="fw-bold fs18">لیست محصولات</h4>
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-success bg-admin-green">افزودن محصول جدید</a>
    </div>

    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="table-wrap">
        <table class="table">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>عنوان محصول</th>
                    <th>قیمت</th>
                    <th>درصد مالیات</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><?php echo e($product->title); ?></td>
                    <td><?php echo e(number_format($product->price)); ?></td>
                    <td><?php echo e($product->tax_percent); ?>%</td>
                    <td>
                        <a href="<?php echo e(route('products.students', $product->id)); ?>" class="btn btn-sm btn-success bg-admin-green">
                            دانش‌آموزان
                        </a>

                        <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST" class="d-inline" onsubmit="return confirm('آیا مطمئن هستید؟');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-secondary">حذف</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">هیچ محصولی ثبت نشده است.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/products/index.blade.php ENDPATH**/ ?>
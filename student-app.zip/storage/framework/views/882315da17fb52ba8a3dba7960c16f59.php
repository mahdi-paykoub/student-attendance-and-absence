

<?php $__env->startSection('content'); ?>
<div class="">
    <h3 class="mb-4 fw-bold fs18">لیست کاربران</h3>

    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>


    <div class="table-wrap">
        <table class="table table-striped">
            <thead class="table-light">
                <tr>
                    <th>آیدی</th>
                    <th>نام</th>
                    <th>ایمیل</th>
                    <th>تاریخ ثبت‌نام</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e(\Morilog\Jalali\Jalalian::fromDateTime($user->created_at)->format('Y/m/d')); ?></td>
                    <td>

                        <!-- دکمه تبدیل به ادمین فقط برای کاربران عادی -->
                        <?php if($user->is_admin == 0): ?>
                        <form action="<?php echo e(route('users.makeAdmin', $user)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-success bg-admin-green">تبدیل به ادمین</button>
                        </form>
                        <?php endif; ?>
                        <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" class="d-inline" onsubmit="return confirm('آیا مطمئن هستید؟')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-secondary">حذف</button>
                        </form>


                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-center">هیچ کاربری یافت نشد.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/users/index.blade.php ENDPATH**/ ?>
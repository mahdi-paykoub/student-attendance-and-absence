

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h3 class="fw-bold mb-4">مدیریت شماره صندلی‌ها</h3>

    <?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="table-wrap">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <p style="font-size: 14px;">با زدن دکمه روبرو، شماره صندلی‌ها طبق پایه، رشته و جنسیت از ابتدا محاسبه می‌شوند.</p>
            <form action="<?php echo e(route('seats.generate')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-success bg-admin-green px-4">
                    <i class="bi bi-grid-fill"></i> تولید شماره صندلی‌ها
                </button>
            </form>
        </div>

        <div>
            <table class="table table-striped align-middle">
                <thead class="table-light">
                    <tr>
                        <th>عکس</th>
                        <th>نام</th>
                        <th>نام خانوادگی</th>
                        <th>شماره صندلی</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <!-- <td><?php echo e($loop->iteration); ?></td> -->

                        
                        <td>
                            <?php if($student->photo): ?>
                            <img src="<?php echo e(route('students.photo', basename($student->photo))); ?>"
                                alt="photo" width="50" height="50" class="rounded-circle">
                            <?php else: ?>
                            <img src="<?php echo e(asset('images/no-photo.png')); ?>" width="50" height="50" class="rounded-circle">
                            <?php endif; ?>
                        </td>

                        <td><?php echo e($student->first_name); ?></td>
                        <td><?php echo e($student->last_name); ?></td>
                        <td>
                            <?php if($student->seat_number): ?>
                            <?php echo e($student->seat_number); ?>

                            <?php endif; ?>
                        </td>


                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="11" class="text-center text-muted">هیچ دانش‌آموزی ثبت نشده است.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/seats/index.blade.php ENDPATH**/ ?>
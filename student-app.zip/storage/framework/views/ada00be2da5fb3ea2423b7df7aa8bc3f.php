<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'مدیریت'); ?></title>
    <!-- Bootstrap RTL -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
</head>

<body class="bg-light">

    <div class="container-fluid mt-5">
        <?php echo $__env->yieldContent('content'); ?>
    </div>


    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/layouts/auth-app.blade.php ENDPATH**/ ?>
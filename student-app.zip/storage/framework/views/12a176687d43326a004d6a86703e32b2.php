

<?php $__env->startSection('title', 'تخصیص محصول به دانش‌آموز'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <div class="card shadow-sm p-3">

        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('student-products.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            
            <div class="mb-3">
                <label class="form-label">دانش‌آموز</label>
                <select name="student_id" class="form-select <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">انتخاب کنید...</option>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($student->id); ?>" <?php echo e(old('student_id') == $student->id ? 'selected' : ''); ?>>
                        <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?> - <?php echo e($student->national_code); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mb-3">
                <label class="form-label">محصول</label>
                <select name="product_id" class="form-select <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">انتخاب کنید...</option>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($product->id); ?>" <?php echo e(old('product_id') == $product->id ? 'selected' : ''); ?>>
                        <?php echo e($product->title); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="mb-3">
                <label class="form-label">نوع پرداخت</label>
                <select name="payment_type" id="payment_type" class="form-select <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">انتخاب کنید...</option>
                    <option value="cash" <?php echo e(old('payment_type')=='cash' ? 'selected' : ''); ?>>نقدی</option>
                    <option value="installment" <?php echo e(old('payment_type')=='installment' ? 'selected' : ''); ?>>اقساطی</option>
                </select>
                <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div id="cash_fields" style="display:none;">
                <div class="mb-3">
                    <label class="form-label">نوع دستگاه پوز</label>
                    <input type="text" name="pos_type" value="<?php echo e(old('pos_type')); ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">نوع کارت</label>
                    <input type="text" name="card_type" value="<?php echo e(old('card_type')); ?>" class="form-control">
                </div>
            </div>

            
            <div id="installment_fields" style="display:none;">
                <div id="checks_container">
                    
                </div>
                <button type="button" class="btn btn-secondary mb-2" id="add_check">افزودن چک</button>
            </div>

            <button type="submit" class="btn btn-success bg-admin-green">تخصیص محصول</button>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const paymentType = document.getElementById('payment_type');
        const cashFields = document.getElementById('cash_fields');
        const installmentFields = document.getElementById('installment_fields');
        const addCheckBtn = document.getElementById('add_check');
        const checksContainer = document.getElementById('checks_container');

        function togglePaymentFields() {
            if (paymentType.value === 'cash') {
                cashFields.style.display = 'block';
                installmentFields.style.display = 'none';
            } else if (paymentType.value === 'installment') {
                cashFields.style.display = 'none';
                installmentFields.style.display = 'block';
            } else {
                cashFields.style.display = 'none';
                installmentFields.style.display = 'none';
            }
        }

        paymentType.addEventListener('change', togglePaymentFields);
        togglePaymentFields();

        let checkIndex = 0;
        addCheckBtn.addEventListener('click', function() {
            const html = `
            <div class="border p-3 mb-2">
                <div class="mb-2">
                    <label>نام صاحب چک</label>
                    <input type="text" name="checks[${checkIndex}][owner]" class="form-control" required>
                </div>
                <div class="mb-2">
                    <label>شماره موبایل صاحب چک</label>
                    <input type="text" name="checks[${checkIndex}][phone]" class="form-control" required>
                </div>
                <div class="mb-2">
                    <label>عکس چک</label>
                    <input type="file" name="checks[${checkIndex}][image]" class="form-control">
                </div>
            </div>
        `;
            checksContainer.insertAdjacentHTML('beforeend', html);
            checkIndex++;
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Lenovo\Desktop\student-app\resources\views/student_product/create.blade.php ENDPATH**/ ?>